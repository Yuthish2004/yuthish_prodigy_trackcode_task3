let board = ["", "", "", "", "", "", "", "", ""];
let currentPlayer = "X";
let gameActive = true;
let isComputerOpponent = false;

const cells = document.querySelectorAll(".cell");
const boardContainer = document.getElementById("gameBoard");
const playerVsPlayerButton = document.getElementById("playerVsPlayer");
const playerVsComputerButton = document.getElementById("playerVsComputer");

playerVsPlayerButton.addEventListener("click", () => {
    resetGame();
    isComputerOpponent = false;
});

playerVsComputerButton.addEventListener("click", () => {
    resetGame();
    isComputerOpponent = true;
});

function checkWin() {
    const winPatterns = [
        [0, 1, 2], [3, 4, 5], [6, 7, 8],  // Rows
        [0, 3, 6], [1, 4, 7], [2, 5, 8],  // Columns
        [0, 4, 8], [2, 4, 6]              // Diagonals
    ];
    for (let pattern of winPatterns) {
        if (
            board[pattern[0]] !== "" &&
            board[pattern[0]] === board[pattern[1]] &&
            board[pattern[0]] === board[pattern[2]]
        ) {
            return true;
        }
    }
    return false;
}

function checkDraw() {
    return !board.includes("");
}

function handleClick(index) {
    if (board[index] === "" && gameActive) {
        board[index] = currentPlayer;
        cells[index].textContent = currentPlayer;
        if (checkWin()) {
            alert(`Player ${currentPlayer} wins!`);
            gameActive = false;
        } else if (checkDraw()) {
            alert("It's a draw!");
            gameActive = false;
        } else {
            currentPlayer = currentPlayer === "X" ? "O" : "X";
            if (isComputerOpponent && currentPlayer === "O") {
                computerMove();
            }
        }
    }
}

function computerMove() {
    let emptyCells = board
        .map((val, index) => (val === "" ? index : null))
        .filter(index => index !== null);
    
    if (emptyCells.length > 0) {
        let randomIndex = emptyCells[Math.floor(Math.random() * emptyCells.length)];
        handleClick(randomIndex);
    }
}

function resetGame() {
    board = ["", "", "", "", "", "", "", "", ""];
    currentPlayer = "X";
    gameActive = true;
    cells.forEach(cell => (cell.textContent = ""));
}

cells.forEach((cell, index) => {
    cell.addEventListener("click", () => handleClick(index));
});
